package org.fife.ui.rtextarea;

import javax.swing.Icon;

public interface GutterIconInfo {
  Icon getIcon();
  
  int getMarkedOffset();
  
  String getToolTip();
}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\fif\\ui\rtextarea\GutterIconInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */