/*     */ package org.fife.ui.rtextarea;
/*     */ 
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SearchContext
/*     */   implements Cloneable
/*     */ {
/*     */   public static final String PROPERTY_SEARCH_FOR = "Search.searchFor";
/*     */   public static final String PROPERTY_REPLACE_WITH = "Search.replaceWith";
/*     */   public static final String PROPERTY_MATCH_CASE = "Search.MatchCase";
/*     */   public static final String PROPERTY_MATCH_WHOLE_WORD = "Search.MatchWholeWord";
/*     */   public static final String PROPERTY_SEARCH_FORWARD = "Search.Forward";
/*     */   public static final String PROPERTY_SELECTION_ONLY = "Search.SelectionOnly";
/*     */   public static final String PROPERTY_USE_REGEX = "Search.UseRegex";
/*     */   public static final String PROPERTY_MARK_ALL = "Search.MarkAll";
/*     */   private String searchFor;
/*     */   private String replaceWith;
/*     */   private boolean forward;
/*     */   private boolean matchCase;
/*     */   private boolean wholeWord;
/*     */   private boolean regex;
/*     */   private boolean selectionOnly;
/*     */   private boolean markAll;
/*     */   private PropertyChangeSupport support;
/*     */   
/*     */   public SearchContext() {
/*  69 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SearchContext(String searchFor) {
/*  80 */     this(searchFor, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SearchContext(String searchFor, boolean matchCase) {
/*  92 */     this.support = new PropertyChangeSupport(this);
/*  93 */     this.searchFor = searchFor;
/*  94 */     this.matchCase = matchCase;
/*  95 */     this.markAll = true;
/*  96 */     this.forward = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener l) {
/* 107 */     this.support.addPropertyChangeListener(l);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SearchContext clone() {
/*     */     try {
/* 114 */       SearchContext context = null;
/* 115 */       context = (SearchContext)super.clone();
/*     */       
/* 117 */       context.support = new PropertyChangeSupport(context);
/* 118 */       return context;
/* 119 */     } catch (CloneNotSupportedException cnse) {
/* 120 */       throw new RuntimeException("Should never happen", cnse);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void firePropertyChange(String property, boolean oldValue, boolean newValue) {
/* 127 */     this.support.firePropertyChange(property, oldValue, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void firePropertyChange(String property, String oldValue, String newValue) {
/* 133 */     this.support.firePropertyChange(property, oldValue, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getMarkAll() {
/* 144 */     return this.markAll;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getMatchCase() {
/* 155 */     return this.matchCase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getReplaceWith() {
/* 167 */     return this.replaceWith;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSearchFor() {
/* 179 */     return this.searchFor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSearchForward() {
/* 191 */     return this.forward;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSearchSelectionOnly() {
/* 203 */     return this.selectionOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getWholeWord() {
/* 218 */     return this.wholeWord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRegularExpression() {
/* 229 */     return this.regex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener l) {
/* 240 */     this.support.removePropertyChangeListener(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarkAll(boolean markAll) {
/* 252 */     if (markAll != this.markAll) {
/* 253 */       this.markAll = markAll;
/* 254 */       firePropertyChange("Search.MarkAll", !markAll, markAll);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMatchCase(boolean matchCase) {
/* 267 */     if (matchCase != this.matchCase) {
/* 268 */       this.matchCase = matchCase;
/* 269 */       firePropertyChange("Search.MatchCase", !matchCase, matchCase);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRegularExpression(boolean regex) {
/* 282 */     if (regex != this.regex) {
/* 283 */       this.regex = regex;
/* 284 */       firePropertyChange("Search.UseRegex", !regex, regex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReplaceWith(String replaceWith) {
/* 299 */     if ((replaceWith == null && this.replaceWith != null) || (replaceWith != null && 
/* 300 */       !replaceWith.equals(this.replaceWith))) {
/* 301 */       String old = this.replaceWith;
/* 302 */       this.replaceWith = replaceWith;
/* 303 */       firePropertyChange("Search.replaceWith", old, replaceWith);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSearchFor(String searchFor) {
/* 317 */     if ((searchFor == null && this.searchFor != null) || (searchFor != null && 
/* 318 */       !searchFor.equals(this.searchFor))) {
/* 319 */       String old = this.searchFor;
/* 320 */       this.searchFor = searchFor;
/* 321 */       firePropertyChange("Search.searchFor", old, searchFor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSearchForward(boolean forward) {
/* 335 */     if (forward != this.forward) {
/* 336 */       this.forward = forward;
/* 337 */       firePropertyChange("Search.Forward", !forward, forward);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSearchSelectionOnly(boolean selectionOnly) {
/* 354 */     if (selectionOnly != this.selectionOnly) {
/* 355 */       this.selectionOnly = selectionOnly;
/* 356 */       firePropertyChange("Search.SelectionOnly", !selectionOnly, selectionOnly);
/*     */       
/* 358 */       if (selectionOnly) {
/* 359 */         throw new UnsupportedOperationException("Searching in selection is not currently supported");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWholeWord(boolean wholeWord) {
/* 378 */     if (wholeWord != this.wholeWord) {
/* 379 */       this.wholeWord = wholeWord;
/* 380 */       firePropertyChange("Search.MatchWholeWord", !wholeWord, wholeWord);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 387 */     return "[SearchContext: searchFor=" + 
/* 388 */       getSearchFor() + ", replaceWith=" + 
/* 389 */       getReplaceWith() + ", matchCase=" + 
/* 390 */       getMatchCase() + ", wholeWord=" + 
/* 391 */       getWholeWord() + ", regex=" + 
/* 392 */       isRegularExpression() + ", markAll=" + 
/* 393 */       getMarkAll() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\fif\\ui\rtextarea\SearchContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */