/*     */ package org.fife.ui.rtextarea;
/*     */ 
/*     */ import javax.swing.text.BadLocationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RDocumentCharSequence
/*     */   implements CharSequence
/*     */ {
/*     */   private RDocument doc;
/*     */   private int start;
/*     */   private int end;
/*     */   
/*     */   RDocumentCharSequence(RDocument doc, int start) {
/*  38 */     this(doc, start, doc.getLength());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RDocumentCharSequence(RDocument doc, int start, int end) {
/*  50 */     this.doc = doc;
/*  51 */     this.start = start;
/*  52 */     this.end = end;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char charAt(int index) {
/*  61 */     if (index < 0 || index >= length()) {
/*  62 */       throw new IndexOutOfBoundsException("Index " + index + " is not in range [0-" + 
/*  63 */           length() + ")");
/*     */     }
/*     */     try {
/*  66 */       return this.doc.charAt(this.start + index);
/*  67 */     } catch (BadLocationException ble) {
/*  68 */       throw new IndexOutOfBoundsException(ble.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/*  78 */     return this.end - this.start;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharSequence subSequence(int start, int end) {
/*  87 */     if (start < 0) {
/*  88 */       throw new IndexOutOfBoundsException("start must be >= 0 (" + start + ")");
/*     */     }
/*     */     
/*  91 */     if (end < 0) {
/*  92 */       throw new IndexOutOfBoundsException("end must be >= 0 (" + end + ")");
/*     */     }
/*     */     
/*  95 */     if (end > length()) {
/*  96 */       throw new IndexOutOfBoundsException("end must be <= " + 
/*  97 */           length() + " (" + end + ")");
/*     */     }
/*  99 */     if (start > end) {
/* 100 */       throw new IndexOutOfBoundsException("start (" + start + ") cannot be > end (" + end + ")");
/*     */     }
/*     */     
/* 103 */     int newStart = this.start + start;
/* 104 */     int newEnd = this.start + end;
/* 105 */     return new RDocumentCharSequence(this.doc, newStart, newEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     try {
/* 115 */       return this.doc.getText(this.start, length());
/* 116 */     } catch (BadLocationException ble) {
/* 117 */       ble.printStackTrace();
/* 118 */       return "";
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\fif\\ui\rtextarea\RDocumentCharSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */