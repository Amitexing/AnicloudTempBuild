/*     */ package org.fife.ui.rtextarea;
/*     */ import java.awt.Color;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.ActionMap;
/*     */ import javax.swing.InputMap;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.TransferHandler;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.ActionMapUIResource;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.InputMapUIResource;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ import javax.swing.plaf.basic.BasicBorders;
/*     */ import javax.swing.plaf.basic.BasicTextAreaUI;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Caret;
/*     */ import javax.swing.text.EditorKit;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import javax.swing.text.Keymap;
/*     */ import javax.swing.text.PlainView;
/*     */ import javax.swing.text.View;
/*     */ import javax.swing.text.WrappedPlainView;
/*     */ 
/*     */ public class RTextAreaUI extends BasicTextAreaUI {
/*     */   private static final String SHARED_ACTION_MAP_NAME = "RTextAreaUI.actionMap";
/*  37 */   private static final EditorKit DEFAULT_KIT = new RTextAreaEditorKit(); private static final String SHARED_INPUT_MAP_NAME = "RTextAreaUI.inputMap"; protected RTextArea textArea;
/*  38 */   private static final TransferHandler DEFAULT_TRANSFER_HANDLER = new RTATextTransferHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String RTEXTAREA_KEYMAP_NAME = "RTextAreaKeymap";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ComponentUI createUI(JComponent textArea) {
/*  51 */     return new RTextAreaUI(textArea);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RTextAreaUI(JComponent textArea) {
/*  63 */     if (!(textArea instanceof RTextArea)) {
/*  64 */       throw new IllegalArgumentException("RTextAreaUI is for instances of RTextArea only!");
/*     */     }
/*     */     
/*  67 */     this.textArea = (RTextArea)textArea;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void correctNimbusDefaultProblems(JTextComponent editor) {
/*  91 */     Color c = editor.getCaretColor();
/*  92 */     if (c == null) {
/*  93 */       editor.setCaretColor(RTextArea.getDefaultCaretColor());
/*     */     }
/*     */     
/*  96 */     c = editor.getSelectionColor();
/*  97 */     if (c == null) {
/*  98 */       c = UIManager.getColor("nimbusSelectionBackground");
/*  99 */       if (c == null) {
/* 100 */         c = UIManager.getColor("textHighlight");
/* 101 */         if (c == null) {
/* 102 */           c = new ColorUIResource(Color.BLUE);
/*     */         }
/*     */       } 
/* 105 */       editor.setSelectionColor(c);
/*     */     } 
/*     */     
/* 108 */     c = editor.getSelectedTextColor();
/* 109 */     if (c == null) {
/* 110 */       c = UIManager.getColor("nimbusSelectedText");
/* 111 */       if (c == null) {
/* 112 */         c = UIManager.getColor("textHighlightText");
/* 113 */         if (c == null) {
/* 114 */           c = new ColorUIResource(Color.WHITE);
/*     */         }
/*     */       } 
/* 117 */       editor.setSelectedTextColor(c);
/*     */     } 
/*     */     
/* 120 */     c = editor.getDisabledTextColor();
/* 121 */     if (c == null) {
/* 122 */       c = UIManager.getColor("nimbusDisabledText");
/* 123 */       if (c == null) {
/* 124 */         c = UIManager.getColor("textInactiveText");
/* 125 */         if (c == null) {
/* 126 */           c = new ColorUIResource(Color.DARK_GRAY);
/*     */         }
/*     */       } 
/* 129 */       editor.setDisabledTextColor(c);
/*     */     } 
/*     */     
/* 132 */     Border border = editor.getBorder();
/* 133 */     if (border == null) {
/* 134 */       editor.setBorder(new BasicBorders.MarginBorder());
/*     */     }
/*     */     
/* 137 */     Insets margin = editor.getMargin();
/* 138 */     if (margin == null) {
/* 139 */       editor.setMargin(new InsetsUIResource(2, 2, 2, 2));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public View create(Element elem) {
/* 154 */     if (this.textArea.getLineWrap()) {
/* 155 */       return new WrappedPlainView(elem, this.textArea.getWrapStyleWord());
/*     */     }
/*     */     
/* 158 */     return new PlainView(elem);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Caret createCaret() {
/* 171 */     Caret caret = new ConfigurableCaret();
/* 172 */     caret.setBlinkRate(500);
/* 173 */     return caret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Keymap createKeymap() {
/* 190 */     Keymap map = JTextComponent.getKeymap("RTextAreaKeymap");
/* 191 */     if (map == null) {
/* 192 */       Keymap parent = JTextComponent.getKeymap("default");
/* 193 */       map = JTextComponent.addKeymap("RTextAreaKeymap", parent);
/* 194 */       map.setDefaultAction(new RTextAreaEditorKit.DefaultKeyTypedAction());
/*     */     } 
/*     */     
/* 197 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ActionMap createRTextAreaActionMap() {
/* 217 */     ActionMap map = new ActionMapUIResource();
/* 218 */     Action[] actions = this.textArea.getActions();
/* 219 */     int n = actions.length;
/* 220 */     for (Action a : actions) {
/* 221 */       map.put(a.getValue("Name"), a);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 226 */     map.put(TransferHandler.getCutAction().getValue("Name"), 
/* 227 */         TransferHandler.getCutAction());
/* 228 */     map.put(TransferHandler.getCopyAction().getValue("Name"), 
/* 229 */         TransferHandler.getCopyAction());
/* 230 */     map.put(TransferHandler.getPasteAction().getValue("Name"), 
/* 231 */         TransferHandler.getPasteAction());
/*     */     
/* 233 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getActionMapName() {
/* 246 */     return "RTextAreaUI.actionMap";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EditorKit getEditorKit(JTextComponent tc) {
/* 259 */     return DEFAULT_KIT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RTextArea getRTextArea() {
/* 269 */     return this.textArea;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ActionMap getRTextAreaActionMap() {
/* 289 */     ActionMap map = (ActionMap)UIManager.get(getActionMapName());
/* 290 */     if (map == null) {
/* 291 */       map = createRTextAreaActionMap();
/* 292 */       UIManager.put(getActionMapName(), map);
/*     */     } 
/*     */     
/* 295 */     ActionMap componentMap = new ActionMapUIResource();
/* 296 */     componentMap.put("requestFocus", new FocusAction());
/*     */     
/* 298 */     if (map != null) {
/* 299 */       componentMap.setParent(map);
/*     */     }
/* 301 */     return componentMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputMap getRTextAreaInputMap() {
/* 316 */     InputMap map = new InputMapUIResource();
/* 317 */     InputMap shared = (InputMap)UIManager.get("RTextAreaUI.inputMap");
/* 318 */     if (shared == null) {
/* 319 */       shared = new RTADefaultInputMap();
/* 320 */       UIManager.put("RTextAreaUI.inputMap", shared);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 325 */     map.setParent(shared);
/* 326 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Rectangle getVisibleEditorRect() {
/* 342 */     Rectangle alloc = this.textArea.getBounds();
/* 343 */     if (alloc.width > 0 && alloc.height > 0) {
/* 344 */       alloc.x = alloc.y = 0;
/* 345 */       Insets insets = this.textArea.getInsets();
/* 346 */       alloc.x += insets.left;
/* 347 */       alloc.y += insets.top;
/* 348 */       alloc.width -= insets.left + insets.right;
/* 349 */       alloc.height -= insets.top + insets.bottom;
/* 350 */       return alloc;
/*     */     } 
/* 352 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void installDefaults() {
/* 359 */     super.installDefaults();
/*     */     
/* 361 */     JTextComponent editor = getComponent();
/* 362 */     editor.setFont(RTextAreaBase.getDefaultFont());
/*     */ 
/*     */ 
/*     */     
/* 366 */     correctNimbusDefaultProblems(editor);
/*     */     
/* 368 */     editor.setTransferHandler(DEFAULT_TRANSFER_HANDLER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void installKeyboardActions() {
/* 389 */     RTextArea textArea = getRTextArea();
/*     */ 
/*     */ 
/*     */     
/* 393 */     textArea.setKeymap(createKeymap());
/*     */ 
/*     */ 
/*     */     
/* 397 */     InputMap map = getRTextAreaInputMap();
/* 398 */     SwingUtilities.replaceUIInputMap(textArea, 0, map);
/*     */ 
/*     */     
/* 401 */     ActionMap am = getRTextAreaActionMap();
/* 402 */     if (am != null) {
/* 403 */       SwingUtilities.replaceUIActionMap(textArea, am);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void installUI(JComponent c) {
/* 415 */     if (!(c instanceof RTextArea)) {
/* 416 */       throw new Error("RTextAreaUI needs an instance of RTextArea!");
/*     */     }
/* 418 */     super.installUI(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintBackground(Graphics g) {
/* 426 */     Color bg = this.textArea.getBackground();
/* 427 */     if (bg != null) {
/* 428 */       g.setColor(bg);
/*     */       
/* 430 */       Rectangle r = g.getClipBounds();
/* 431 */       g.fillRect(r.x, r.y, r.width, r.height);
/*     */     } 
/*     */     
/* 434 */     paintEditorAugmentations(g);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintCurrentLineHighlight(Graphics g, Rectangle visibleRect) {
/* 447 */     if (this.textArea.getHighlightCurrentLine()) {
/*     */       
/* 449 */       Caret caret = this.textArea.getCaret();
/* 450 */       if (caret.getDot() == caret.getMark()) {
/*     */         
/* 452 */         Color highlight = this.textArea.getCurrentLineHighlightColor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 460 */         int height = this.textArea.getLineHeight();
/*     */         
/* 462 */         if (this.textArea.getFadeCurrentLineHighlight()) {
/* 463 */           Graphics2D g2d = (Graphics2D)g;
/* 464 */           Color bg = this.textArea.getBackground();
/* 465 */           GradientPaint paint = new GradientPaint(visibleRect.x, 0.0F, highlight, (visibleRect.x + visibleRect.width), 0.0F, (bg == null) ? Color.WHITE : bg);
/*     */ 
/*     */ 
/*     */           
/* 469 */           g2d.setPaint(paint);
/* 470 */           g2d.fillRect(visibleRect.x, this.textArea.currentCaretY, visibleRect.width, height);
/*     */         }
/*     */         else {
/*     */           
/* 474 */           g.setColor(highlight);
/* 475 */           g.fillRect(visibleRect.x, this.textArea.currentCaretY, visibleRect.width, height);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintEditorAugmentations(Graphics g) {
/* 493 */     Rectangle visibleRect = this.textArea.getVisibleRect();
/* 494 */     paintLineHighlights(g);
/* 495 */     paintCurrentLineHighlight(g, visibleRect);
/* 496 */     paintMarginLine(g, visibleRect);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintLineHighlights(Graphics g) {
/* 506 */     LineHighlightManager lhm = this.textArea.getLineHighlightManager();
/* 507 */     if (lhm != null) {
/* 508 */       lhm.paintLineHighlights(g);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintMarginLine(Graphics g, Rectangle visibleRect) {
/* 520 */     if (this.textArea.isMarginLineEnabled()) {
/* 521 */       g.setColor(this.textArea.getMarginLineColor());
/* 522 */       Insets insets = this.textArea.getInsets();
/* 523 */       int marginLineX = this.textArea.getMarginLinePixelLocation() + ((insets == null) ? 0 : insets.left);
/*     */       
/* 525 */       g.drawLine(marginLineX, visibleRect.y, marginLineX, visibleRect.y + visibleRect.height);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintSafely(Graphics g) {
/* 535 */     if (!this.textArea.isOpaque()) {
/* 536 */       paintEditorAugmentations(g);
/*     */     }
/* 538 */     super.paintSafely(g);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int yForLine(int line) throws BadLocationException {
/* 564 */     int startOffs = this.textArea.getLineStartOffset(line);
/* 565 */     return yForLineContaining(startOffs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int yForLineContaining(int offs) throws BadLocationException {
/* 592 */     Rectangle r = modelToView(this.textArea, offs);
/* 593 */     return (r != null) ? r.y : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class FocusAction
/*     */     extends AbstractAction
/*     */   {
/*     */     public void actionPerformed(ActionEvent e) {
/* 604 */       RTextAreaUI.this.textArea.requestFocus();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEnabled() {
/* 609 */       return RTextAreaUI.this.textArea.isEditable();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\fif\\ui\rtextarea\RTextAreaUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */