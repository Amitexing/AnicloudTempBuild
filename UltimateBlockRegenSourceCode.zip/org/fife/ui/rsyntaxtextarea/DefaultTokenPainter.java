/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import javax.swing.text.TabExpander;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultTokenPainter
/*     */   implements TokenPainter
/*     */ {
/*  41 */   private Rectangle2D.Float bgRect = new Rectangle2D.Float();
/*     */ 
/*     */ 
/*     */   
/*     */   private static char[] tabBuf;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float paint(Token token, Graphics2D g, float x, float y, RSyntaxTextArea host, TabExpander e) {
/*  51 */     return paint(token, g, x, y, host, e, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float paint(Token token, Graphics2D g, float x, float y, RSyntaxTextArea host, TabExpander e, float clipStart) {
/*  61 */     return paintImpl(token, g, x, y, host, e, clipStart, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float paint(Token token, Graphics2D g, float x, float y, RSyntaxTextArea host, TabExpander e, float clipStart, boolean paintBG) {
/*  72 */     return paintImpl(token, g, x, y, host, e, clipStart, !paintBG, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintBackground(float x, float y, float width, float height, Graphics2D g, int fontAscent, RSyntaxTextArea host, Color color) {
/*  92 */     g.setColor(color);
/*  93 */     this.bgRect.setRect(x, y - fontAscent, width, height);
/*     */     
/*  95 */     g.fillRect((int)x, (int)(y - fontAscent), (int)width, (int)height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected float paintImpl(Token token, Graphics2D g, float x, float y, RSyntaxTextArea host, TabExpander e, float clipStart, boolean selected, boolean useSTC) {
/* 106 */     int origX = (int)x;
/* 107 */     int textOffs = token.getTextOffset();
/* 108 */     char[] text = token.getTextArray();
/* 109 */     int end = textOffs + token.length();
/* 110 */     float nextX = x;
/* 111 */     int flushLen = 0;
/* 112 */     int flushIndex = textOffs;
/*     */     
/* 114 */     Color fg = useSTC ? host.getSelectedTextColor() : host.getForegroundForToken(token);
/* 115 */     Color bg = selected ? null : host.getBackgroundForToken(token);
/* 116 */     g.setFont(host.getFontForTokenType(token.getType()));
/* 117 */     FontMetrics fm = host.getFontMetricsForTokenType(token.getType());
/*     */     
/* 119 */     for (int i = textOffs; i < end; i++) {
/* 120 */       switch (text[i]) {
/*     */         case '\t':
/* 122 */           nextX = e.nextTabStop(x + fm
/* 123 */               .charsWidth(text, flushIndex, flushLen), 0);
/* 124 */           if (bg != null) {
/* 125 */             paintBackground(x, y, nextX - x, fm.getHeight(), g, fm
/* 126 */                 .getAscent(), host, bg);
/*     */           }
/* 128 */           if (flushLen > 0) {
/* 129 */             g.setColor(fg);
/* 130 */             g.drawChars(text, flushIndex, flushLen, (int)x, (int)y);
/* 131 */             flushLen = 0;
/*     */           } 
/* 133 */           flushIndex = i + 1;
/* 134 */           x = nextX;
/*     */           break;
/*     */         default:
/* 137 */           flushLen++;
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 142 */     nextX = x + fm.charsWidth(text, flushIndex, flushLen);
/* 143 */     Rectangle r = host.getMatchRectangle();
/*     */     
/* 145 */     if (flushLen > 0 && nextX >= clipStart) {
/* 146 */       if (bg != null) {
/* 147 */         paintBackground(x, y, nextX - x, fm.getHeight(), g, fm
/* 148 */             .getAscent(), host, bg);
/* 149 */         if (token.length() == 1 && r != null && r.x == x) {
/* 150 */           ((RSyntaxTextAreaUI)host.getUI()).paintMatchedBracketImpl(g, host, r);
/*     */         }
/*     */       } 
/*     */       
/* 154 */       g.setColor(fg);
/* 155 */       g.drawChars(text, flushIndex, flushLen, (int)x, (int)y);
/*     */     } 
/*     */     
/* 158 */     if (host.getUnderlineForToken(token)) {
/* 159 */       g.setColor(fg);
/* 160 */       int y2 = (int)(y + 1.0F);
/* 161 */       g.drawLine(origX, y2, (int)nextX, y2);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     if (host.getPaintTabLines() && origX == (host.getMargin()).left) {
/* 168 */       paintTabLines(token, origX, (int)y, (int)nextX, g, e, host);
/*     */     }
/*     */     
/* 171 */     return nextX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float paintSelected(Token token, Graphics2D g, float x, float y, RSyntaxTextArea host, TabExpander e, boolean useSTC) {
/* 182 */     return paintSelected(token, g, x, y, host, e, 0.0F, useSTC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float paintSelected(Token token, Graphics2D g, float x, float y, RSyntaxTextArea host, TabExpander e, float clipStart, boolean useSTC) {
/* 193 */     return paintImpl(token, g, x, y, host, e, clipStart, true, useSTC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintTabLines(Token token, int x, int y, int endX, Graphics2D g, TabExpander e, RSyntaxTextArea host) {
/* 220 */     if (token.getType() != 21) {
/* 221 */       int offs = 0;
/* 222 */       for (; offs < token.length() && 
/* 223 */         RSyntaxUtilities.isWhitespace(token.charAt(offs)); offs++);
/*     */ 
/*     */ 
/*     */       
/* 227 */       if (offs < 2) {
/*     */         return;
/*     */       }
/*     */       
/* 231 */       endX = (int)token.getWidthUpTo(offs, host, e, 0.0F);
/*     */     } 
/*     */ 
/*     */     
/* 235 */     FontMetrics fm = host.getFontMetricsForTokenType(token.getType());
/* 236 */     int tabSize = host.getTabSize();
/* 237 */     if (tabBuf == null || tabBuf.length < tabSize) {
/* 238 */       tabBuf = new char[tabSize];
/* 239 */       for (int i = 0; i < tabSize; i++) {
/* 240 */         tabBuf[i] = ' ';
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     int tabW = fm.charsWidth(tabBuf, 0, tabSize);
/*     */ 
/*     */ 
/*     */     
/* 252 */     g.setColor(host.getTabLineColor());
/* 253 */     int x0 = x + tabW;
/* 254 */     int y0 = y - fm.getAscent();
/* 255 */     if ((y0 & 0x1) > 0)
/*     */     {
/* 257 */       y0++;
/*     */     }
/*     */ 
/*     */     
/* 261 */     Token next = token.getNextToken();
/* 262 */     if (next == null || !next.isPaintable()) {
/* 263 */       endX++;
/*     */     }
/* 265 */     while (x0 < endX) {
/* 266 */       int y1 = y0;
/* 267 */       int y2 = y0 + host.getLineHeight();
/* 268 */       while (y1 < y2) {
/* 269 */         g.drawLine(x0, y1, x0, y1);
/* 270 */         y1 += 2;
/*     */       } 
/*     */       
/* 273 */       x0 += tabW;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\fif\\ui\rsyntaxtextarea\DefaultTokenPainter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */