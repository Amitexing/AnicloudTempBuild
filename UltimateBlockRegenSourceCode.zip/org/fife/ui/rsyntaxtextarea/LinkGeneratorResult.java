package org.fife.ui.rsyntaxtextarea;

import javax.swing.event.HyperlinkEvent;

public interface LinkGeneratorResult {
  HyperlinkEvent execute();
  
  int getSourceOffset();
}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\fif\\ui\rsyntaxtextarea\LinkGeneratorResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */