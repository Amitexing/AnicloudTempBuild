package org.fife.ui.rsyntaxtextarea.parser;

import java.util.EventListener;
import javax.swing.event.HyperlinkEvent;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;

public interface ExtendedHyperlinkListener extends EventListener {
  void linkClicked(RSyntaxTextArea paramRSyntaxTextArea, HyperlinkEvent paramHyperlinkEvent);
}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\fif\\ui\rsyntaxtextarea\parser\ExtendedHyperlinkListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */