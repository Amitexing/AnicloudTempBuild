package org.fife.ui.rsyntaxtextarea;

import javax.swing.text.Element;

public class WrappedSyntaxView2 {
  public WrappedSyntaxView2(Element root) {}
}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\fif\\ui\rsyntaxtextarea\WrappedSyntaxView2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */