/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantString
/*    */   extends Constant
/*    */ {
/*    */   protected int stringIndex;
/*    */   
/*    */   public ConstantString(int stringIndex) {
/* 14 */     super((byte)8);
/* 15 */     this.stringIndex = stringIndex;
/*    */   }
/*    */   
/*    */   public int getStringIndex() {
/* 19 */     return this.stringIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\constant\ConstantString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */