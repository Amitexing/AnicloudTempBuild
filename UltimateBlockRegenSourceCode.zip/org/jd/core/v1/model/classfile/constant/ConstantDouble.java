/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantDouble
/*    */   extends ConstantValue
/*    */ {
/*    */   protected double value;
/*    */   
/*    */   public ConstantDouble(double value) {
/* 14 */     super((byte)6);
/* 15 */     this.value = value;
/*    */   }
/*    */   
/*    */   public double getValue() {
/* 19 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\constant\ConstantDouble.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */