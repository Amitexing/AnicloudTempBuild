/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantFloat
/*    */   extends ConstantValue
/*    */ {
/*    */   protected float value;
/*    */   
/*    */   public ConstantFloat(float value) {
/* 14 */     super((byte)4);
/* 15 */     this.value = value;
/*    */   }
/*    */   
/*    */   public float getValue() {
/* 19 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\constant\ConstantFloat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */