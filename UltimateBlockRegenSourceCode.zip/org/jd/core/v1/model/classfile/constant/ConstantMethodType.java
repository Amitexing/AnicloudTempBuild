/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantMethodType
/*    */   extends Constant
/*    */ {
/*    */   protected int descriptorIndex;
/*    */   
/*    */   public ConstantMethodType(int descriptorIndex) {
/* 14 */     super((byte)16);
/* 15 */     this.descriptorIndex = descriptorIndex;
/*    */   }
/*    */   
/*    */   public int getDescriptorIndex() {
/* 19 */     return this.descriptorIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\constant\ConstantMethodType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */