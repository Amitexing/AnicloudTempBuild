/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantLong
/*    */   extends ConstantValue
/*    */ {
/*    */   protected long value;
/*    */   
/*    */   public ConstantLong(long value) {
/* 14 */     super((byte)5);
/* 15 */     this.value = value;
/*    */   }
/*    */   
/*    */   public long getValue() {
/* 19 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\constant\ConstantLong.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */