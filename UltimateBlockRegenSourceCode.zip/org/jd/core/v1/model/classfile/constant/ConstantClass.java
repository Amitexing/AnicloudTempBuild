/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantClass
/*    */   extends Constant
/*    */ {
/*    */   protected int nameIndex;
/*    */   
/*    */   public ConstantClass(int nameIndex) {
/* 14 */     super((byte)7);
/* 15 */     this.nameIndex = nameIndex;
/*    */   }
/*    */   
/*    */   public int getNameIndex() {
/* 19 */     return this.nameIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\constant\ConstantClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */