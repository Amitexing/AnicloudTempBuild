package org.jd.core.v1.model.classfile;

public interface Constants {
  public static final int ACC_PUBLIC = 1;
  
  public static final int ACC_PRIVATE = 2;
  
  public static final int ACC_PROTECTED = 4;
  
  public static final int ACC_STATIC = 8;
  
  public static final int ACC_FINAL = 16;
  
  public static final int ACC_SYNCHRONIZED = 32;
  
  public static final int ACC_SUPER = 32;
  
  public static final int ACC_OPEN = 32;
  
  public static final int ACC_TRANSITIVE = 32;
  
  public static final int ACC_VOLATILE = 64;
  
  public static final int ACC_BRIDGE = 64;
  
  public static final int ACC_STATIC_PHASE = 64;
  
  public static final int ACC_TRANSIENT = 128;
  
  public static final int ACC_VARARGS = 128;
  
  public static final int ACC_NATIVE = 256;
  
  public static final int ACC_INTERFACE = 512;
  
  public static final int ACC_ABSTRACT = 1024;
  
  public static final int ACC_STRICT = 2048;
  
  public static final int ACC_SYNTHETIC = 4096;
  
  public static final int ACC_ANNOTATION = 8192;
  
  public static final int ACC_ENUM = 16384;
  
  public static final int ACC_MODULE = 32768;
  
  public static final int ACC_MANDATED = 32768;
}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\Constants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */