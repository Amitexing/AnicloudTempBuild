/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeLocalVariableTable
/*    */   implements Attribute
/*    */ {
/*    */   protected LocalVariable[] localVariableTable;
/*    */   
/*    */   public AttributeLocalVariableTable(LocalVariable[] localVariableTable) {
/* 14 */     this.localVariableTable = localVariableTable;
/*    */   }
/*    */   
/*    */   public LocalVariable[] getLocalVariableTable() {
/* 18 */     return this.localVariableTable;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\attribute\AttributeLocalVariableTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */