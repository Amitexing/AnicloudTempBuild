/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeLocalVariableTypeTable
/*    */   implements Attribute
/*    */ {
/*    */   protected LocalVariableType[] localVariableTypeTable;
/*    */   
/*    */   public AttributeLocalVariableTypeTable(LocalVariableType[] localVariableTypeTable) {
/* 14 */     this.localVariableTypeTable = localVariableTypeTable;
/*    */   }
/*    */   
/*    */   public LocalVariableType[] getLocalVariableTypeTable() {
/* 18 */     return this.localVariableTypeTable;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\attribute\AttributeLocalVariableTypeTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */