/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementValueArrayValue
/*    */   implements ElementValue
/*    */ {
/*    */   protected ElementValue[] values;
/*    */   
/*    */   public ElementValueArrayValue(ElementValue[] values) {
/* 14 */     this.values = values;
/*    */   }
/*    */   
/*    */   public ElementValue[] getValues() {
/* 18 */     return this.values;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(ElementValueVisitor visitor) {
/* 23 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\attribute\ElementValueArrayValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */