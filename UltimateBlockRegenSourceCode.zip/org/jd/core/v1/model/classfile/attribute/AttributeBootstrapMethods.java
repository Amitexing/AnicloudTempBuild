/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeBootstrapMethods
/*    */   implements Attribute
/*    */ {
/*    */   protected BootstrapMethod[] bootstrapMethods;
/*    */   
/*    */   public AttributeBootstrapMethods(BootstrapMethod[] bootstrapMethods) {
/* 14 */     this.bootstrapMethods = bootstrapMethods;
/*    */   }
/*    */   
/*    */   public BootstrapMethod[] getBootstrapMethods() {
/* 18 */     return this.bootstrapMethods;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\attribute\AttributeBootstrapMethods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */