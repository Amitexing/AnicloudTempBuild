/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeParameterAnnotations
/*    */   implements Attribute
/*    */ {
/*    */   protected Annotations[] parameterAnnotations;
/*    */   
/*    */   public AttributeParameterAnnotations(Annotations[] parameterAnnotations) {
/* 14 */     this.parameterAnnotations = parameterAnnotations;
/*    */   }
/*    */   
/*    */   public Annotations[] getParameterAnnotations() {
/* 18 */     return this.parameterAnnotations;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\attribute\AttributeParameterAnnotations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */