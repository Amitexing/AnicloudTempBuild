/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeLineNumberTable
/*    */   implements Attribute
/*    */ {
/*    */   protected LineNumber[] lineNumberTable;
/*    */   
/*    */   public AttributeLineNumberTable(LineNumber[] lineNumberTable) {
/* 14 */     this.lineNumberTable = lineNumberTable;
/*    */   }
/*    */   
/*    */   public LineNumber[] getLineNumberTable() {
/* 18 */     return this.lineNumberTable;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\attribute\AttributeLineNumberTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */