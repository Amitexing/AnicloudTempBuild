/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ import org.jd.core.v1.model.classfile.constant.ConstantClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeModuleMainClass
/*    */   implements Attribute
/*    */ {
/*    */   protected ConstantClass mainClass;
/*    */   
/*    */   public AttributeModuleMainClass(ConstantClass mainClass) {
/* 16 */     this.mainClass = mainClass;
/*    */   }
/*    */   
/*    */   public ConstantClass getMainClass() {
/* 20 */     return this.mainClass;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\attribute\AttributeModuleMainClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */