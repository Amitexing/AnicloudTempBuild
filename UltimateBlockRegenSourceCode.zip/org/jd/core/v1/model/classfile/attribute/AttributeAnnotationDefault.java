/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeAnnotationDefault
/*    */   implements Attribute
/*    */ {
/*    */   protected ElementValue defaultValue;
/*    */   
/*    */   public AttributeAnnotationDefault(ElementValue defaultValue) {
/* 14 */     this.defaultValue = defaultValue;
/*    */   }
/*    */   
/*    */   public ElementValue getDefaultValue() {
/* 18 */     return this.defaultValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\attribute\AttributeAnnotationDefault.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */