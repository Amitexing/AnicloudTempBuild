/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeExceptions
/*    */   implements Attribute
/*    */ {
/*    */   protected String[] exceptionTypeNames;
/*    */   
/*    */   public AttributeExceptions(String[] exceptionTypeNames) {
/* 14 */     this.exceptionTypeNames = exceptionTypeNames;
/*    */   }
/*    */   
/*    */   public String[] getExceptionTypeNames() {
/* 18 */     return this.exceptionTypeNames;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\attribute\AttributeExceptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */