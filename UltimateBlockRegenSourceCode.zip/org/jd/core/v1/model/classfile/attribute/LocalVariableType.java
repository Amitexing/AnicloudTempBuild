/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVariableType
/*    */ {
/*    */   protected int startPc;
/*    */   protected int length;
/*    */   protected String name;
/*    */   protected String signature;
/*    */   protected int index;
/*    */   
/*    */   public LocalVariableType(int startPc, int length, String name, String signature, int index) {
/* 18 */     this.startPc = startPc;
/* 19 */     this.length = length;
/* 20 */     this.name = name;
/* 21 */     this.signature = signature;
/* 22 */     this.index = index;
/*    */   }
/*    */   
/*    */   public int getStartPc() {
/* 26 */     return this.startPc;
/*    */   }
/*    */   
/*    */   public int getLength() {
/* 30 */     return this.length;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 34 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getSignature() {
/* 38 */     return this.signature;
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 42 */     return this.index;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 47 */     StringBuilder sb = new StringBuilder();
/*    */     
/* 49 */     sb.append("LocalVariableType{index=").append(this.index);
/* 50 */     sb.append(", name=").append(this.name);
/* 51 */     sb.append(", signature=").append(this.signature);
/* 52 */     sb.append(", index=").append(this.index);
/* 53 */     sb.append(", startPc=").append(this.startPc);
/* 54 */     sb.append(", length=").append(this.length);
/*    */     
/* 56 */     return sb.append("}").toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\classfile\attribute\LocalVariableType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */