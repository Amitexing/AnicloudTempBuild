/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ import org.jd.core.v1.model.fragment.FlexibleFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpacerFragment
/*    */   extends FlexibleFragment
/*    */   implements JavaFragment
/*    */ {
/*    */   public SpacerFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label) {
/* 14 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 19 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javafragment\SpacerFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */