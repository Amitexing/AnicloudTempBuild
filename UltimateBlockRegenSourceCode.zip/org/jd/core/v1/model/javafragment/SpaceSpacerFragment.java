/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpaceSpacerFragment
/*    */   extends SpacerFragment
/*    */   implements JavaFragment
/*    */ {
/*    */   public SpaceSpacerFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label) {
/* 13 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 18 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javafragment\SpaceSpacerFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */