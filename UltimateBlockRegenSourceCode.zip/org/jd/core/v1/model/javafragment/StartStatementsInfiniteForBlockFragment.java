/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartStatementsInfiniteForBlockFragment
/*    */   extends StartStatementsBlockFragment
/*    */ {
/*    */   public StartStatementsInfiniteForBlockFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label) {
/* 12 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/*    */   }
/*    */   
/*    */   public StartStatementsInfiniteForBlockFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label, StartStatementsBlockFragment.Group group) {
/* 16 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label, group);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 21 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javafragment\StartStatementsInfiniteForBlockFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */