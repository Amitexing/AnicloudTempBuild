/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ import org.jd.core.v1.model.fragment.EndFlexibleBlockFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndBlockFragment
/*    */   extends EndFlexibleBlockFragment
/*    */   implements JavaFragment
/*    */ {
/*    */   protected StartBlockFragment start;
/*    */   
/*    */   public EndBlockFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label, StartBlockFragment start) {
/* 16 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/* 17 */     this.start = start;
/* 18 */     start.setEndArrayInitializerBlockFragment(this);
/*    */   }
/*    */   
/*    */   public void setLineCount(int lineCount) {
/* 22 */     this.lineCount = lineCount;
/*    */   }
/*    */   
/*    */   public StartBlockFragment getStartArrayInitializerBlockFragment() {
/* 26 */     return this.start;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean incLineCount(boolean force) {
/* 31 */     if (this.lineCount < this.maximalLineCount) {
/* 32 */       this.lineCount++;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 41 */       return true;
/*    */     } 
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean decLineCount(boolean force) {
/* 49 */     if (this.lineCount > this.minimalLineCount) {
/* 50 */       this.lineCount--;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 58 */       return true;
/*    */     } 
/* 60 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 66 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javafragment\EndBlockFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */