/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ import org.jd.core.v1.model.fragment.StartFlexibleBlockFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartSingleStatementBlockFragment
/*    */   extends StartFlexibleBlockFragment
/*    */   implements JavaFragment
/*    */ {
/*    */   protected EndSingleStatementBlockFragment end;
/*    */   
/*    */   public StartSingleStatementBlockFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label) {
/* 16 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/*    */   }
/*    */   
/*    */   public void setLineCount(int lineCount) {
/* 20 */     this.lineCount = lineCount;
/*    */   }
/*    */   
/*    */   public EndSingleStatementBlockFragment getEndSingleStatementBlockFragment() {
/* 24 */     return this.end;
/*    */   }
/*    */   
/*    */   public void setEndSingleStatementBlockFragment(EndSingleStatementBlockFragment end) {
/* 28 */     this.end = end;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean incLineCount(boolean force) {
/* 33 */     if (this.lineCount < this.maximalLineCount) {
/* 34 */       this.lineCount++;
/*    */       
/* 36 */       if (!force)
/*    */       {
/* 38 */         if (this.end.getLineCount() == 0) {
/* 39 */           this.end.setLineCount(1);
/*    */         }
/*    */       }
/*    */       
/* 43 */       return true;
/*    */     } 
/* 45 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean decLineCount(boolean force) {
/* 51 */     if (this.lineCount > this.minimalLineCount) {
/* 52 */       this.lineCount--;
/*    */       
/* 54 */       if (!force)
/*    */       {
/* 56 */         if (this.lineCount == 1) {
/* 57 */           this.end.setLineCount(1);
/*    */         }
/*    */       }
/*    */       
/* 61 */       return true;
/*    */     } 
/* 63 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 69 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javafragment\StartSingleStatementBlockFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */