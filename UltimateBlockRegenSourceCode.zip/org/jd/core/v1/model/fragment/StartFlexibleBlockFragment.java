/*    */ package org.jd.core.v1.model.fragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class StartFlexibleBlockFragment
/*    */   extends FlexibleFragment
/*    */ {
/*    */   protected StartFlexibleBlockFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label) {
/* 13 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(FragmentVisitor visitor) {
/* 18 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\fragment\StartFlexibleBlockFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */