/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import org.jd.core.v1.model.javasyntax.reference.BaseAnnotationReference;
/*    */ import org.jd.core.v1.model.javasyntax.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormalParameter
/*    */   implements BaseFormalParameter
/*    */ {
/*    */   protected BaseAnnotationReference annotationReferences;
/*    */   protected boolean fina1;
/*    */   protected Type type;
/*    */   protected boolean varargs;
/*    */   protected String name;
/*    */   
/*    */   public FormalParameter(Type type, String name) {
/* 21 */     this.type = type;
/* 22 */     this.name = name;
/*    */   }
/*    */   
/*    */   public FormalParameter(BaseAnnotationReference annotationReferences, Type type, String name) {
/* 26 */     this.annotationReferences = annotationReferences;
/* 27 */     this.type = type;
/* 28 */     this.name = name;
/*    */   }
/*    */   
/*    */   public FormalParameter(Type type, boolean varargs, String name) {
/* 32 */     this.type = type;
/* 33 */     this.varargs = varargs;
/* 34 */     this.name = name;
/*    */   }
/*    */   
/*    */   public FormalParameter(BaseAnnotationReference annotationReferences, Type type, boolean varargs, String name) {
/* 38 */     this.annotationReferences = annotationReferences;
/* 39 */     this.type = type;
/* 40 */     this.varargs = varargs;
/* 41 */     this.name = name;
/*    */   }
/*    */   
/*    */   public BaseAnnotationReference getAnnotationReferences() {
/* 45 */     return this.annotationReferences;
/*    */   }
/*    */   
/*    */   public boolean isFinal() {
/* 49 */     return this.fina1;
/*    */   }
/*    */   
/*    */   public void setFinal(boolean fina1) {
/* 53 */     this.fina1 = fina1;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 57 */     return this.type;
/*    */   }
/*    */   
/*    */   public boolean isVarargs() {
/* 61 */     return this.varargs;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 65 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 69 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 74 */     visitor.visit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     String s = "FormalParameter{";
/*    */     
/* 81 */     if (this.annotationReferences != null) {
/* 82 */       s = s + this.annotationReferences + " ";
/*    */     }
/* 84 */     if (this.varargs) {
/* 85 */       s = s + this.type.createType(this.type.getDimension() - 1) + "... ";
/*    */     } else {
/* 87 */       s = s + this.type + " ";
/*    */     } 
/* 89 */     return s + this.name + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\FormalParameter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */