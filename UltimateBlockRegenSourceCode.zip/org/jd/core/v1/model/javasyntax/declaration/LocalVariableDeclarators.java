/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.jd.core.v1.util.DefaultList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVariableDeclarators
/*    */   extends DefaultList<LocalVariableDeclarator>
/*    */   implements BaseLocalVariableDeclarator
/*    */ {
/*    */   public LocalVariableDeclarators() {}
/*    */   
/*    */   public LocalVariableDeclarators(int capacity) {
/* 19 */     super(capacity);
/*    */   }
/*    */   
/*    */   public LocalVariableDeclarators(Collection<LocalVariableDeclarator> collection) {
/* 23 */     super(collection);
/* 24 */     assert collection != null && collection.size() > 1 : "Uses 'LocalVariableDeclarator' instead";
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLineNumber() {
/* 29 */     return isEmpty() ? 0 : get(0).getLineNumber();
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 34 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\LocalVariableDeclarators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */