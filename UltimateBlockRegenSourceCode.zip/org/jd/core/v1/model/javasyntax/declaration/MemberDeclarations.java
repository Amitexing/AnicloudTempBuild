/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.jd.core.v1.util.DefaultList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemberDeclarations
/*    */   extends DefaultList<MemberDeclaration>
/*    */   implements BaseMemberDeclaration
/*    */ {
/*    */   public MemberDeclarations() {}
/*    */   
/*    */   public MemberDeclarations(int capacity) {
/* 18 */     super(capacity);
/*    */   }
/*    */   
/*    */   public MemberDeclarations(Collection<MemberDeclaration> collection) {
/* 22 */     super(collection);
/* 23 */     assert collection != null && collection.size() > 1 : "Uses 'MemberDeclaration' implementation instead";
/*    */   }
/*    */ 
/*    */   
/*    */   public MemberDeclarations(MemberDeclaration declaration, MemberDeclaration... declarations) {
/* 28 */     super(declaration, declarations);
/* 29 */     assert declarations != null && declarations.length > 0 : "Uses 'MemberDeclaration' implementation instead";
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 34 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\MemberDeclarations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */