/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVariableDeclarator
/*    */   implements BaseLocalVariableDeclarator
/*    */ {
/*    */   protected int lineNumber;
/*    */   protected String name;
/*    */   protected int dimension;
/*    */   protected VariableInitializer variableInitializer;
/*    */   
/*    */   public LocalVariableDeclarator(String name) {
/* 17 */     this.name = name;
/*    */   }
/*    */   
/*    */   public LocalVariableDeclarator(int lineNumber, String name) {
/* 21 */     this.lineNumber = lineNumber;
/* 22 */     this.name = name;
/*    */   }
/*    */   
/*    */   public LocalVariableDeclarator(String name, int dimension) {
/* 26 */     this.name = name;
/* 27 */     this.dimension = dimension;
/*    */   }
/*    */   
/*    */   public LocalVariableDeclarator(String name, VariableInitializer variableInitializer) {
/* 31 */     this.name = name;
/* 32 */     this.variableInitializer = variableInitializer;
/*    */   }
/*    */   
/*    */   public LocalVariableDeclarator(int lineNumber, String name, VariableInitializer variableInitializer) {
/* 36 */     this.lineNumber = lineNumber;
/* 37 */     this.name = name;
/* 38 */     this.variableInitializer = variableInitializer;
/*    */   }
/*    */   
/*    */   public LocalVariableDeclarator(String name, int dimension, VariableInitializer variableInitializer) {
/* 42 */     this.name = name;
/* 43 */     this.dimension = dimension;
/* 44 */     this.variableInitializer = variableInitializer;
/*    */   }
/*    */   
/*    */   public LocalVariableDeclarator(int lineNumber, String name, int dimension, VariableInitializer variableInitializer) {
/* 48 */     this.lineNumber = lineNumber;
/* 49 */     this.name = name;
/* 50 */     this.dimension = dimension;
/* 51 */     this.variableInitializer = variableInitializer;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 55 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 59 */     this.name = name;
/*    */   }
/*    */   
/*    */   public int getDimension() {
/* 63 */     return this.dimension;
/*    */   }
/*    */   
/*    */   public void setDimension(int dimension) {
/* 67 */     this.dimension = dimension;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLineNumber() {
/* 72 */     return this.lineNumber;
/*    */   }
/*    */   
/*    */   public VariableInitializer getVariableInitializer() {
/* 76 */     return this.variableInitializer;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 81 */     visitor.visit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 86 */     return "LocalVariableDeclarator{name=" + this.name + ", dimension" + this.dimension + ", variableInitializer=" + this.variableInitializer + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\LocalVariableDeclarator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */