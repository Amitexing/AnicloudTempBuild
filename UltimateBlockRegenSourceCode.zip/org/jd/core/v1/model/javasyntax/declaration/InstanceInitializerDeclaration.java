/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import org.jd.core.v1.model.javasyntax.statement.BaseStatement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InstanceInitializerDeclaration
/*    */   implements MemberDeclaration
/*    */ {
/*    */   protected String descriptor;
/*    */   protected BaseStatement statements;
/*    */   
/*    */   public InstanceInitializerDeclaration(String descriptor, BaseStatement statements) {
/* 17 */     this.descriptor = descriptor;
/* 18 */     this.statements = statements;
/*    */   }
/*    */   
/*    */   public String getDescriptor() {
/* 22 */     return this.descriptor;
/*    */   }
/*    */   
/*    */   public BaseStatement getStatements() {
/* 26 */     return this.statements;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 31 */     visitor.visit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 36 */     return "InstanceInitializerDeclaration{}";
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\InstanceInitializerDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */