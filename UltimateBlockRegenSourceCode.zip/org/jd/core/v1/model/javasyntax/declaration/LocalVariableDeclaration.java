/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import org.jd.core.v1.model.javasyntax.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVariableDeclaration
/*    */   implements Declaration
/*    */ {
/*    */   protected boolean fina1 = false;
/*    */   protected Type type;
/*    */   protected BaseLocalVariableDeclarator localVariableDeclarators;
/*    */   
/*    */   public LocalVariableDeclaration(Type type, BaseLocalVariableDeclarator localVariableDeclarators) {
/* 18 */     this.type = type;
/* 19 */     this.localVariableDeclarators = localVariableDeclarators;
/*    */   }
/*    */   
/*    */   public boolean isFinal() {
/* 23 */     return this.fina1;
/*    */   }
/*    */   
/*    */   public void setFinal(boolean fina1) {
/* 27 */     this.fina1 = fina1;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 31 */     return this.type;
/*    */   }
/*    */   
/*    */   public BaseLocalVariableDeclarator getLocalVariableDeclarators() {
/* 35 */     return this.localVariableDeclarators;
/*    */   }
/*    */   
/*    */   public void setLocalVariableDeclarators(BaseLocalVariableDeclarator localVariableDeclarators) {
/* 39 */     this.localVariableDeclarators = localVariableDeclarators;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 44 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\LocalVariableDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */