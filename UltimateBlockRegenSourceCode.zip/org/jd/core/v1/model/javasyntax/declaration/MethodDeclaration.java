/*     */ package org.jd.core.v1.model.javasyntax.declaration;
/*     */ 
/*     */ import org.jd.core.v1.model.javasyntax.reference.BaseAnnotationReference;
/*     */ import org.jd.core.v1.model.javasyntax.reference.ElementValue;
/*     */ import org.jd.core.v1.model.javasyntax.statement.BaseStatement;
/*     */ import org.jd.core.v1.model.javasyntax.type.BaseType;
/*     */ import org.jd.core.v1.model.javasyntax.type.BaseTypeParameter;
/*     */ import org.jd.core.v1.model.javasyntax.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodDeclaration
/*     */   implements MemberDeclaration
/*     */ {
/*     */   protected BaseAnnotationReference annotationReferences;
/*     */   protected int flags;
/*     */   protected String name;
/*     */   protected BaseTypeParameter typeParameters;
/*     */   protected Type returnedType;
/*     */   protected BaseFormalParameter formalParameters;
/*     */   protected BaseType exceptionTypes;
/*     */   protected String descriptor;
/*     */   protected BaseStatement statements;
/*     */   protected ElementValue defaultAnnotationValue;
/*     */   
/*     */   public MethodDeclaration(int flags, String name, Type returnedType, String descriptor) {
/*  30 */     this.flags = flags;
/*  31 */     this.name = name;
/*  32 */     this.returnedType = returnedType;
/*  33 */     this.descriptor = descriptor;
/*     */   }
/*     */   
/*     */   public MethodDeclaration(int flags, String name, Type returnedType, String descriptor, BaseStatement statements) {
/*  37 */     this.flags = flags;
/*  38 */     this.name = name;
/*  39 */     this.returnedType = returnedType;
/*  40 */     this.descriptor = descriptor;
/*  41 */     this.statements = statements;
/*     */   }
/*     */   
/*     */   public MethodDeclaration(int flags, String name, Type returnedType, String descriptor, ElementValue defaultAnnotationValue) {
/*  45 */     this.flags = flags;
/*  46 */     this.name = name;
/*  47 */     this.returnedType = returnedType;
/*  48 */     this.descriptor = descriptor;
/*  49 */     this.defaultAnnotationValue = defaultAnnotationValue;
/*     */   }
/*     */   
/*     */   public MethodDeclaration(int flags, String name, Type returnedType, BaseFormalParameter formalParameters, String descriptor, BaseStatement statements) {
/*  53 */     this.flags = flags;
/*  54 */     this.name = name;
/*  55 */     this.returnedType = returnedType;
/*  56 */     this.formalParameters = formalParameters;
/*  57 */     this.descriptor = descriptor;
/*  58 */     this.statements = statements;
/*     */   }
/*     */   
/*     */   public MethodDeclaration(int flags, String name, Type returnedType, BaseFormalParameter formalParameters, String descriptor, ElementValue defaultAnnotationValue) {
/*  62 */     this.flags = flags;
/*  63 */     this.name = name;
/*  64 */     this.returnedType = returnedType;
/*  65 */     this.formalParameters = formalParameters;
/*  66 */     this.descriptor = descriptor;
/*  67 */     this.defaultAnnotationValue = defaultAnnotationValue;
/*     */   }
/*     */   
/*     */   public MethodDeclaration(BaseAnnotationReference annotationReferences, int flags, String name, BaseTypeParameter typeParameters, Type returnedType, BaseFormalParameter formalParameters, BaseType exceptionTypes, String descriptor, BaseStatement statements, ElementValue defaultAnnotationValue) {
/*  71 */     this.annotationReferences = annotationReferences;
/*  72 */     this.flags = flags;
/*  73 */     this.name = name;
/*  74 */     this.typeParameters = typeParameters;
/*  75 */     this.returnedType = returnedType;
/*  76 */     this.formalParameters = formalParameters;
/*  77 */     this.exceptionTypes = exceptionTypes;
/*  78 */     this.descriptor = descriptor;
/*  79 */     this.statements = statements;
/*  80 */     this.defaultAnnotationValue = defaultAnnotationValue;
/*     */   }
/*     */   
/*     */   public BaseAnnotationReference getAnnotationReferences() {
/*  84 */     return this.annotationReferences;
/*     */   }
/*     */   
/*     */   public int getFlags() {
/*  88 */     return this.flags;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  92 */     return this.name;
/*     */   }
/*     */   
/*     */   public BaseTypeParameter getTypeParameters() {
/*  96 */     return this.typeParameters;
/*     */   }
/*     */   
/*     */   public Type getReturnedType() {
/* 100 */     return this.returnedType;
/*     */   }
/*     */   
/*     */   public BaseFormalParameter getFormalParameters() {
/* 104 */     return this.formalParameters;
/*     */   }
/*     */   
/*     */   public BaseType getExceptionTypes() {
/* 108 */     return this.exceptionTypes;
/*     */   }
/*     */   
/*     */   public String getDescriptor() {
/* 112 */     return this.descriptor;
/*     */   }
/*     */   
/*     */   public BaseStatement getStatements() {
/* 116 */     return this.statements;
/*     */   }
/*     */   
/*     */   public ElementValue getDefaultAnnotationValue() {
/* 120 */     return this.defaultAnnotationValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(DeclarationVisitor visitor) {
/* 125 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 130 */     return "MethodDeclaration{" + this.name + " " + this.descriptor + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\MethodDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */