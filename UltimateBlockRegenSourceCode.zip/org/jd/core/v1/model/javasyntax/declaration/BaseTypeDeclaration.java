package org.jd.core.v1.model.javasyntax.declaration;

public interface BaseTypeDeclaration extends BaseMemberDeclaration {}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\BaseTypeDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */