/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.jd.core.v1.util.DefaultList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormalParameters
/*    */   extends DefaultList<FormalParameter>
/*    */   implements BaseFormalParameter
/*    */ {
/*    */   public FormalParameters() {}
/*    */   
/*    */   public FormalParameters(Collection<FormalParameter> collection) {
/* 18 */     super(collection);
/* 19 */     assert collection != null && collection.size() > 1 : "Uses 'FormalParameter' instead";
/*    */   }
/*    */ 
/*    */   
/*    */   public FormalParameters(FormalParameter parameter, FormalParameter... parameters) {
/* 24 */     super(parameter, parameters);
/* 25 */     assert parameters != null && parameters.length > 0 : "Uses 'FormalParameter' instead";
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 30 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\FormalParameters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */