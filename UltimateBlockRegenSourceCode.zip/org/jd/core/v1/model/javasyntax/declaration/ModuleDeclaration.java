/*     */ package org.jd.core.v1.model.javasyntax.declaration;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleDeclaration
/*     */   extends TypeDeclaration
/*     */ {
/*     */   protected String version;
/*     */   protected List<ModuleInfo> requires;
/*     */   protected List<PackageInfo> exports;
/*     */   protected List<PackageInfo> opens;
/*     */   protected List<String> uses;
/*     */   protected List<ServiceInfo> provides;
/*     */   
/*     */   public ModuleDeclaration(int flags, String internalName, String name, String version, List<ModuleInfo> requires, List<PackageInfo> exports, List<PackageInfo> opens, List<String> uses, List<ServiceInfo> provides) {
/*  21 */     super(null, flags, internalName, name, null);
/*  22 */     this.version = version;
/*  23 */     this.requires = requires;
/*  24 */     this.exports = exports;
/*  25 */     this.opens = opens;
/*  26 */     this.uses = uses;
/*  27 */     this.provides = provides;
/*     */   }
/*     */   
/*  30 */   public String getVersion() { return this.version; }
/*  31 */   public List<ModuleInfo> getRequires() { return this.requires; }
/*  32 */   public List<PackageInfo> getExports() { return this.exports; }
/*  33 */   public List<PackageInfo> getOpens() { return this.opens; }
/*  34 */   public List<String> getUses() { return this.uses; } public List<ServiceInfo> getProvides() {
/*  35 */     return this.provides;
/*     */   }
/*     */   
/*     */   public void accept(DeclarationVisitor visitor) {
/*  39 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  44 */     return "ModuleDeclaration{" + this.internalTypeName + "}";
/*     */   }
/*     */   
/*     */   public static class ModuleInfo {
/*     */     protected String name;
/*     */     protected int flags;
/*     */     protected String version;
/*     */     
/*     */     public ModuleInfo(String name, int flags, String version) {
/*  53 */       this.name = name;
/*  54 */       this.flags = flags;
/*  55 */       this.version = version;
/*     */     }
/*     */     
/*  58 */     public String getName() { return this.name; }
/*  59 */     public int getFlags() { return this.flags; } public String getVersion() {
/*  60 */       return this.version;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  64 */       StringBuilder sb = new StringBuilder();
/*     */       
/*  66 */       sb.append("ModuleInfo{name=").append(this.name);
/*  67 */       sb.append(", flags=").append(this.flags);
/*     */       
/*  69 */       if (this.version != null) {
/*  70 */         sb.append(", version=").append(this.version);
/*     */       }
/*     */       
/*  73 */       return sb.append("}").toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class PackageInfo {
/*     */     protected String internalName;
/*     */     protected int flags;
/*     */     protected List<String> moduleInfoNames;
/*     */     
/*     */     public PackageInfo(String internalName, int flags, List<String> moduleInfoNames) {
/*  83 */       this.internalName = internalName;
/*  84 */       this.flags = flags;
/*  85 */       this.moduleInfoNames = moduleInfoNames;
/*     */     }
/*     */     
/*  88 */     public String getInternalName() { return this.internalName; }
/*  89 */     public int getFlags() { return this.flags; } public List<String> getModuleInfoNames() {
/*  90 */       return this.moduleInfoNames;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  94 */       StringBuilder sb = new StringBuilder();
/*     */       
/*  96 */       sb.append("PackageInfo{internalName=").append(this.internalName);
/*  97 */       sb.append(", flags=").append(this.flags);
/*     */       
/*  99 */       if (this.moduleInfoNames != null) {
/* 100 */         sb.append(", moduleInfoNames=").append(this.moduleInfoNames);
/*     */       }
/*     */       
/* 103 */       return sb.append("}").toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ServiceInfo {
/*     */     protected String interfaceTypeName;
/*     */     protected List<String> implementationTypeNames;
/*     */     
/*     */     public ServiceInfo(String interfaceTypeName, List<String> implementationTypeNames) {
/* 112 */       this.interfaceTypeName = interfaceTypeName;
/* 113 */       this.implementationTypeNames = implementationTypeNames;
/*     */     }
/*     */     
/* 116 */     public String getInterfaceTypeName() { return this.interfaceTypeName; } public List<String> getImplementationTypeNames() {
/* 117 */       return this.implementationTypeNames;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 121 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 123 */       sb.append("ServiceInfo{interfaceTypeName=").append(this.interfaceTypeName);
/*     */       
/* 125 */       if (this.implementationTypeNames != null) {
/* 126 */         sb.append(", implementationTypeNames=").append(this.implementationTypeNames);
/*     */       }
/*     */       
/* 129 */       return sb.append("}").toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\ModuleDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */