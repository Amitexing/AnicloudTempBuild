package org.jd.core.v1.model.javasyntax.declaration;

import org.jd.core.v1.util.Base;

public interface BaseFieldDeclarator extends Declaration, Base<FieldDeclarator> {
  void setFieldDeclaration(FieldDeclaration paramFieldDeclaration);
}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\BaseFieldDeclarator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */