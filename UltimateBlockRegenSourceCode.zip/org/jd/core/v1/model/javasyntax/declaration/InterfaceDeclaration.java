/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import org.jd.core.v1.model.javasyntax.reference.BaseAnnotationReference;
/*    */ import org.jd.core.v1.model.javasyntax.type.BaseType;
/*    */ import org.jd.core.v1.model.javasyntax.type.BaseTypeParameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterfaceDeclaration
/*    */   extends TypeDeclaration
/*    */ {
/*    */   protected BaseTypeParameter typeParameters;
/*    */   protected BaseType interfaces;
/*    */   
/*    */   public InterfaceDeclaration(int flags, String internalName, String name, BaseType interfaces) {
/* 19 */     super(null, flags, internalName, name, null);
/* 20 */     this.interfaces = interfaces;
/*    */   }
/*    */   
/*    */   public InterfaceDeclaration(BaseAnnotationReference annotationReferences, int flags, String internalName, String name, BaseTypeParameter typeParameters, BaseType interfaces, BodyDeclaration bodyDeclaration) {
/* 24 */     super(annotationReferences, flags, internalName, name, bodyDeclaration);
/* 25 */     this.typeParameters = typeParameters;
/* 26 */     this.interfaces = interfaces;
/*    */   }
/*    */   
/*    */   public BaseTypeParameter getTypeParameters() {
/* 30 */     return this.typeParameters;
/*    */   }
/*    */   
/*    */   public BaseType getInterfaces() {
/* 34 */     return this.interfaces;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 39 */     visitor.visit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 44 */     return "InterfaceDeclaration{" + this.internalTypeName + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\InterfaceDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */