package org.jd.core.v1.model.javasyntax.declaration;

import org.jd.core.v1.util.Base;

public interface BaseLocalVariableDeclarator extends Declaration, Base<LocalVariableDeclarator> {
  int getLineNumber();
}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\jd\core\v1\model\javasyntax\declaration\BaseLocalVariableDeclarator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */