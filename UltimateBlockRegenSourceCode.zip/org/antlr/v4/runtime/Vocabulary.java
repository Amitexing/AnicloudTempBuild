package org.antlr.v4.runtime;

public interface Vocabulary {
  String getLiteralName(int paramInt);
  
  String getSymbolicName(int paramInt);
  
  String getDisplayName(int paramInt);
}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\antlr\v4\runtime\Vocabulary.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */