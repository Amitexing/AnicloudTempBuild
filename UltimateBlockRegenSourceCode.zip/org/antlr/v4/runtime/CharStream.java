package org.antlr.v4.runtime;

import org.antlr.v4.runtime.misc.Interval;

public interface CharStream extends IntStream {
  String getText(Interval paramInterval);
}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\antlr\v4\runtime\CharStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */