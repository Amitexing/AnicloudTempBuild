/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BasicBlockStartState
/*    */   extends BlockStartState
/*    */ {
/*    */   public int getStateType() {
/* 41 */     return 3;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\antlr\v4\runtime\atn\BasicBlockStartState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */