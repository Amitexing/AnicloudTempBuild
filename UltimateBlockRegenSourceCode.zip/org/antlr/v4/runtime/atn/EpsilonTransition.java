/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EpsilonTransition
/*    */   extends Transition
/*    */ {
/*    */   private final int outermostPrecedenceReturn;
/*    */   
/*    */   public EpsilonTransition(ATNState target) {
/* 40 */     this(target, -1);
/*    */   }
/*    */   
/*    */   public EpsilonTransition(ATNState target, int outermostPrecedenceReturn) {
/* 44 */     super(target);
/* 45 */     this.outermostPrecedenceReturn = outermostPrecedenceReturn;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int outermostPrecedenceReturn() {
/* 57 */     return this.outermostPrecedenceReturn;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 62 */     return 1;
/*    */   }
/*    */   
/*    */   public boolean isEpsilon() {
/* 66 */     return true;
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 70 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return "epsilon";
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\antlr\v4\runtime\atn\EpsilonTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */