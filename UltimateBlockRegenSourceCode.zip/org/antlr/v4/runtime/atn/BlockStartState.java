package org.antlr.v4.runtime.atn;

public abstract class BlockStartState extends DecisionState {
  public BlockEndState endState;
}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\antlr\v4\runtime\atn\BlockStartState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */