/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RuleTransition
/*    */   extends Transition
/*    */ {
/*    */   public final int ruleIndex;
/*    */   public final int precedence;
/*    */   public ATNState followState;
/*    */   
/*    */   @Deprecated
/*    */   public RuleTransition(RuleStartState ruleStart, int ruleIndex, ATNState followState) {
/* 54 */     this(ruleStart, ruleIndex, 0, followState);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RuleTransition(RuleStartState ruleStart, int ruleIndex, int precedence, ATNState followState) {
/* 62 */     super(ruleStart);
/* 63 */     this.ruleIndex = ruleIndex;
/* 64 */     this.precedence = precedence;
/* 65 */     this.followState = followState;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 70 */     return 3;
/*    */   }
/*    */   
/*    */   public boolean isEpsilon() {
/* 74 */     return true;
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 78 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\antlr\v4\runtime\atn\RuleTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */