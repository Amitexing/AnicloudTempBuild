/*     */ package org.antlr.v4.runtime.dfa;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.Vocabulary;
/*     */ import org.antlr.v4.runtime.VocabularyImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DFASerializer
/*     */ {
/*     */   private final DFA dfa;
/*     */   private final Vocabulary vocabulary;
/*     */   
/*     */   @Deprecated
/*     */   public DFASerializer(DFA dfa, String[] tokenNames) {
/*  52 */     this(dfa, VocabularyImpl.fromTokenNames(tokenNames));
/*     */   }
/*     */   
/*     */   public DFASerializer(DFA dfa, Vocabulary vocabulary) {
/*  56 */     this.dfa = dfa;
/*  57 */     this.vocabulary = vocabulary;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  62 */     if (this.dfa.s0 == null) return null; 
/*  63 */     StringBuilder buf = new StringBuilder();
/*  64 */     List<DFAState> states = this.dfa.getStates();
/*  65 */     for (DFAState s : states) {
/*  66 */       int n = 0;
/*  67 */       if (s.edges != null) n = s.edges.length; 
/*  68 */       for (int i = 0; i < n; i++) {
/*  69 */         DFAState t = s.edges[i];
/*  70 */         if (t != null && t.stateNumber != Integer.MAX_VALUE) {
/*  71 */           buf.append(getStateString(s));
/*  72 */           String label = getEdgeLabel(i);
/*  73 */           buf.append("-").append(label).append("->").append(getStateString(t)).append('\n');
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  78 */     String output = buf.toString();
/*  79 */     if (output.length() == 0) return null;
/*     */     
/*  81 */     return output;
/*     */   }
/*     */   
/*     */   protected String getEdgeLabel(int i) {
/*  85 */     return this.vocabulary.getDisplayName(i - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getStateString(DFAState s) {
/*  90 */     int n = s.stateNumber;
/*  91 */     String baseStateStr = (s.isAcceptState ? ":" : "") + "s" + n + (s.requiresFullContext ? "^" : "");
/*  92 */     if (s.isAcceptState) {
/*  93 */       if (s.predicates != null) {
/*  94 */         return baseStateStr + "=>" + Arrays.toString((Object[])s.predicates);
/*     */       }
/*     */       
/*  97 */       return baseStateStr + "=>" + s.prediction;
/*     */     } 
/*     */ 
/*     */     
/* 101 */     return baseStateStr;
/*     */   }
/*     */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\antlr\v4\runtime\dfa\DFASerializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */