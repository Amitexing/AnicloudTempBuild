/*    */ package org.antlr.v4.runtime.tree.xpath;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import org.antlr.v4.runtime.tree.ParseTree;
/*    */ import org.antlr.v4.runtime.tree.Trees;
/*    */ 
/*    */ public class XPathWildcardAnywhereElement
/*    */   extends XPathElement {
/*    */   public XPathWildcardAnywhereElement() {
/* 11 */     super("*");
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ParseTree> evaluate(ParseTree t) {
/* 16 */     if (this.invert) return new ArrayList<ParseTree>(); 
/* 17 */     return Trees.descendants(t);
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\antlr\v4\runtime\tree\xpath\XPathWildcardAnywhereElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */