package org.antlr.v4.runtime.tree.pattern;

abstract class Chunk {}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\antlr\v4\runtime\tree\pattern\Chunk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */