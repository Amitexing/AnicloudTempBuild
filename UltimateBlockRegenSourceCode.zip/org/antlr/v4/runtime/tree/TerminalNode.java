package org.antlr.v4.runtime.tree;

import org.antlr.v4.runtime.Token;

public interface TerminalNode extends ParseTree {
  Token getSymbol();
}


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\antlr\v4\runtime\tree\TerminalNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */