/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.antlr.v4.runtime.atn.ATNState;
/*    */ import org.antlr.v4.runtime.atn.AbstractPredicateTransition;
/*    */ import org.antlr.v4.runtime.atn.PredicateTransition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FailedPredicateException
/*    */   extends RecognitionException
/*    */ {
/*    */   private final int ruleIndex;
/*    */   private final int predicateIndex;
/*    */   private final String predicate;
/*    */   
/*    */   public FailedPredicateException(Parser recognizer) {
/* 51 */     this(recognizer, null);
/*    */   }
/*    */   
/*    */   public FailedPredicateException(Parser recognizer, String predicate) {
/* 55 */     this(recognizer, predicate, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FailedPredicateException(Parser recognizer, String predicate, String message) {
/* 62 */     super(formatMessage(predicate, message), recognizer, recognizer.getInputStream(), recognizer._ctx);
/* 63 */     ATNState s = (recognizer.getInterpreter()).atn.states.get(recognizer.getState());
/*    */     
/* 65 */     AbstractPredicateTransition trans = (AbstractPredicateTransition)s.transition(0);
/* 66 */     if (trans instanceof PredicateTransition) {
/* 67 */       this.ruleIndex = ((PredicateTransition)trans).ruleIndex;
/* 68 */       this.predicateIndex = ((PredicateTransition)trans).predIndex;
/*    */     } else {
/*    */       
/* 71 */       this.ruleIndex = 0;
/* 72 */       this.predicateIndex = 0;
/*    */     } 
/*    */     
/* 75 */     this.predicate = predicate;
/* 76 */     setOffendingToken(recognizer.getCurrentToken());
/*    */   }
/*    */   
/*    */   public int getRuleIndex() {
/* 80 */     return this.ruleIndex;
/*    */   }
/*    */   
/*    */   public int getPredIndex() {
/* 84 */     return this.predicateIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPredicate() {
/* 89 */     return this.predicate;
/*    */   }
/*    */ 
/*    */   
/*    */   private static String formatMessage(String predicate, String message) {
/* 94 */     if (message != null) {
/* 95 */       return message;
/*    */     }
/*    */     
/* 98 */     return String.format(Locale.getDefault(), "failed predicate: {%s}?", new Object[] { predicate });
/*    */   }
/*    */ }


/* Location:              C:\Users\amite\OneDrive\Документы\jd-gui-1.6.6.jar!\org\antlr\v4\runtime\FailedPredicateException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */